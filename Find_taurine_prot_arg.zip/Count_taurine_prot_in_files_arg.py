#!/usr/bin/env python3

import argparse
import os
import pandas as pd

parser = argparse.ArgumentParser(description="Count taurine pathway proteins in files")
parser.add_argument("-f", "--folder", help="Folder with files")
parser.add_argument("-o", "--output", help="Output file")
args, unknown = parser.parse_known_args()


def main():
    # prot of int
    proteins_of_interest = [
    "ADO", "CDO1", "GADL1", "CSAD", "gadB", "FMO", "ggt", "BAAT", "tauD", "tpa", "ald",
    "gudB", "GDH2", "toa", "pta", "xsc", "safD", "ackA", "sauS", "tauF", "isfD", "islA",
    "islB", "tauA", "tauB", "tauC", "tauX"
    ]

    # Folder with TSV
    folder_path = args.folder

    # Create DataFrame for saving results
    results_df = pd.DataFrame(columns=["Genome"] + proteins_of_interest)

    # Run for files
    for file_name in os.listdir(folder_path):
        if file_name.endswith(".tsv"):
            file_path = os.path.join(folder_path, file_name)
            genome_name = os.path.splitext(file_name)[0]
            
            # Read TSV file
            try:
                tsv_data = pd.read_csv(file_path, sep='\t', header=None)
            except Exception as e:
                print(f"Error reading {file_name}: {e}")
                continue
            
            # Count prot of int
            protein_counts = {protein: 0 for protein in proteins_of_interest}
            for protein in tsv_data[0]:
                if protein in protein_counts:
                    protein_counts[protein] += 1
                else:
                    protein_counts["tauX_Sulfoacetaldehyde"] += 1
            
            # Add results to DataFrame
            row_data = [genome_name] + [protein_counts[protein] for protein in proteins_of_interest]
            results_df.loc[len(results_df)] = row_data

    # Save results to file
    results_df.to_csv(args.output, sep='\t', index=False)

if __name__ == "__main__":
    main()
