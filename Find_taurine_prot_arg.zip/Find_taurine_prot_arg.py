#!/usr/bin/env python3

import argparse
import os
#import subprocess

parser = argparse.ArgumentParser(description="Find taurine pathway proteins in EggNog annotation file")
parser.add_argument("-f", "--file", help="Annotation file")
parser.add_argument("-p", "--prot", help="List of proteins of interest")
parser.add_argument("-o", "--output", help="Output file")
args, unknown = parser.parse_known_args()


def parse_annotation_file(annotation_file):
    
    proteins = {}
    with open(annotation_file, 'r') as f:
        for line in f:
            if line.startswith('#'):
                continue
            fields = line.strip().split('\t')
            if len(fields) >= 12:  # Check elements
                protein_id = fields[0]
                #print(protein_id)
                ec_ids = fields[10].split(',')
                if ec_ids[0]=='-':
                    ec_ids=[]
                #print(ec_ids)
                kegg_ids = [kegg.split(':')[1] for kegg in fields[11].split(',') if kegg.startswith('ko:')]
                #print(kegg_ids)
                proteins[protein_id] = {'EC': ec_ids, 'KEGG': kegg_ids, 'Full_string' : fields[1:]}
        #print(proteins)
        
    return proteins


def filter_proteins(annotation_proteins, interesting_proteins_ec, interesting_proteins_add_ko, 
                    interesting_proteins_ko, interesting_proteins_add_ec):
    
    filtered_proteins = {}
        
    for protein_id, ec_kegg_dict in annotation_proteins.items():
        
        EC_ar=ec_kegg_dict['EC']
        KEGG_ar=ec_kegg_dict['KEGG']
        Full_info=ec_kegg_dict['Full_string']
        
        matches_ar=[]
        
        if (len(KEGG_ar)>0) and (len(EC_ar)>0):
            
            for EC_id in EC_ar:
                
                for KEGG_id in KEGG_ar:
                
                    if EC_id in interesting_proteins_ec:
                        
                        if KEGG_id in interesting_proteins_ec[EC_id]:
                            
                            protein_name=interesting_proteins_ec[EC_id][KEGG_id]
                            matches_ar.append([protein_name, EC_id, KEGG_id, Full_info])
                            
                        
                        
        elif (len(KEGG_ar)>0) and (len(EC_ar)==0):
            
            for KEGG_id in KEGG_ar:  
                
                if KEGG_id in interesting_proteins_ko:
                    
                    if len(interesting_proteins_ko[KEGG_id])>1:
                        
                        print(f"Umbiguous match! {protein_id}, '-', {KEGG_id} : {interesting_proteins_ko[KEGG_id]}")
                        
                    else:
                        
                        EC_id=interesting_proteins_ko[KEGG_id].keys()[0]
                        protein_name=interesting_proteins_ko[KEGG_id][EC_id]
                        matches_ar.append([protein_name, EC_id, KEGG_id, Full_info])
                        
        if len(matches_ar)>0:
            filtered_proteins[protein_id]=matches_ar
            
                       
    print(filtered_proteins)
    
    return filtered_proteins



def read_interesting_proteins(prot_file):
    interesting_proteins_ec = {}
    interesting_proteins_add_ko = {}
    
    interesting_proteins_ko = {}
    interesting_proteins_add_ec = {}    
    
    with open(prot_file, 'r') as f:
        for line in f:
            fields = line.strip().split('\t')
            prot_names = fields[0]
            ec_id = fields[1]
            kegg_id = fields[2]
            
            if ec_id!='Na':
            
                if ec_id not in interesting_proteins_ec:
                    interesting_proteins_ec[ec_id] = {kegg_id: prot_names}
                else:
                    if kegg_id not in interesting_proteins_ec[ec_id]:
                        interesting_proteins_ec[ec_id][kegg_id]=prot_names
                    else:
                        print(f'Umbiguous annotation! Several genes with same EC and KEGG ids! {ec_id} {kegg_id}')
            
            elif ec_id=='Na':
                
                if kegg_id not in interesting_proteins_add_ko:
                    interesting_proteins_add_ko[kegg_id] = prot_names 
                    
            if kegg_id!='Na':
            
                if kegg_id not in interesting_proteins_ko:
                    interesting_proteins_ko[kegg_id] = {ec_id: prot_names}
                else:
                    if ec_id not in interesting_proteins_ko[kegg_id]:
                        interesting_proteins_ko[kegg_id][ec_id]=prot_names
                    else:
                        print(f'Umbiguous annotation! Several genes with same EC and KEGG ids! {ec_id} {kegg_id}')
            
            elif kegg_id=='Na':
                
                if ec_id not in interesting_proteins_add_ec:
                    interesting_proteins_add_ec[ec_id] = prot_names 
                
        #print(interesting_proteins)
    return interesting_proteins_ec, interesting_proteins_add_ko, interesting_proteins_ko, interesting_proteins_add_ec


def write_filtered_annotation(output_file, filtered_proteins):
    
    with open(output_file, 'w') as f:
        
        for prot_id, prot_annot_ar in filtered_proteins.items():
            
            for prot_annot in prot_annot_ar:
            
                f.write(f'{prot_annot[0]}\t{prot_annot[1]}\t{prot_annot[2]}\t{prot_id}')
                
                for ele in prot_annot[3]:
                    
                    f.write(f'\t{ele}')
                
                f.write('\n')

def main():
    annotation_file = args.file
    prot_file = args.prot
    output_file = args.output

    annotation_proteins = parse_annotation_file(annotation_file)
    interesting_proteins_ec, interesting_proteins_add_ko, interesting_proteins_ko, interesting_proteins_add_ec = read_interesting_proteins(prot_file)
    
    #print(interesting_proteins_ec)
    #print(interesting_proteins_add_ko)
    #print(interesting_proteins_ko)
    #print(interesting_proteins_add_ec)
    
    filtered_proteins = filter_proteins(annotation_proteins, interesting_proteins_ec, interesting_proteins_add_ko, 
                                        interesting_proteins_ko, interesting_proteins_add_ec)
    write_filtered_annotation(output_file, filtered_proteins)

if __name__ == '__main__':
    main()
