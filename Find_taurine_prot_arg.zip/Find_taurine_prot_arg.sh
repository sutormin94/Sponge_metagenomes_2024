#!/bin/bash
data_dir=/home/lam16/Genomes_final/Compare/EggNog_taurine/EggNog/test
for D in ./*; do
    if [ -d "$D" ]; then
	echo "$D"
        cd "$D"
        for i in `ls -a ./ | grep 'annotations' | sed -r "s/(.+).annotations/\1/" | uniq | sort -d`
		do
			python3 $data_dir/Find_taurine_prot_arg.py -f ./${i}.annotations -p $data_dir/All_prot_cut.txt -o ./${i}_taurine.tsv
		done
        cd ..
    fi
done
