#!/bin/bash
data_dir=/home/lam16/Genomes_final/Compare/EggNog_taurine/EggNog/Test
for D in ./*; do
    if [ -d "$D" ]; then
	echo "$D"
        cd "$D"
	python3 $data_dir/Count_taurine_prot_in_files_arg.py -f ./ -o ./Summary_results.tsv
        cd ..
    fi
done
